{{/*
Expand the name of the chart.
*/}}
{{- define "crw.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "crw.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "crw.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "crw.labels" -}}
helm.sh/chart: {{ include "crw.chart" . }}
{{ include "crw.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "crw.selectorLabels" -}}
app.kubernetes.io/name: {{ include "crw.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "crw.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "crw.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the SearXNG search backend URL
*/}}
{{- define "crw.searchBackendUrl" -}}
{{- if .Values.search.backendUrl -}}
{{- .Values.search.backendUrl -}}
{{- else if (index .Values "searxng" "enabled") -}}
{{- $name := default "searxng" (index .Values "searxng" "nameOverride") -}}
{{- if contains $name .Release.Name -}}
{{- $name = .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name = printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- $port := 8080 -}}
{{- if and (index .Values "searxng" "service") (index .Values "searxng" "service" "port") -}}
{{- $port = index .Values "searxng" "service" "port" -}}
{{- end -}}
{{- printf "http://%s:%d" $name (int $port) -}}
{{- end -}}
{{- end }}
